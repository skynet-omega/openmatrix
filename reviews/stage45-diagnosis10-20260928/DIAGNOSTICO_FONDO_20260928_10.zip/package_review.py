from pathlib import Path
import hashlib,json,zipfile,shutil,subprocess,sys,time,re
p=Path(__file__).resolve().parent;r=p.parents[1]
t0=time.process_time()
for f in ['README.md','MAPA_VIGENTE.md','ESTADO_ACTUAL.md','motor_nuevo/PLAN_ABC.md']:
 dest=p/'continuidad_actual'/f;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/f,dest)
files=[]
for f in sorted(p.rglob('*')):
 if not f.is_file() or any(s in f.parts for s in ['entrega','extraccion_limpia','corruption_checks']):continue
 if f.name in ['MANIFEST.json','ENTREGA.json','PUBLICACION.json','index.git']:continue
 data=f.read_bytes()
 if re.search(rb'apikey_[A-Za-z0-9_]{20,}',data):raise RuntimeError('secreto detectado; no se empaqueta')
 files.append({'path':f.relative_to(p).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(p/'MANIFEST.json').write_text(json.dumps({'scope':'documentary_diagnosis_only','files':files},ensure_ascii=False,indent=2)+'\n')
out=p/'entrega';out.mkdir(exist_ok=True);z=out/'DIAGNOSTICO_FONDO_20260928_10.zip'
if z.exists():raise RuntimeError('entrega ya existe')
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as w:
 for row in files:w.write(p/row['path'],row['path'])
 w.write(p/'MANIFEST.json','MANIFEST.json')
clean=p/'extraccion_limpia';clean.mkdir()
with zipfile.ZipFile(z) as q:q.extractall(clean)
run=subprocess.run([sys.executable,'-B','-O',str(clean/'verify_packet.py')],cwd=clean,check=True,capture_output=True,text=True)
checks=[]
for rel in ['EVIDENCIA_LOCAL.json','HERRAMIENTAS_METADATA.json','MEDICIONES.md']:
 f=clean/rel;orig=f.read_bytes();f.write_bytes(orig+b' ')
 probe=subprocess.run([sys.executable,'-B','-O',str(clean/'verify_packet.py')],cwd=clean,capture_output=True)
 f.write_bytes(orig)
 if probe.returncode==0:raise RuntimeError('corrupcion no detectada')
 checks.append(rel)
rec={'zip_bytes':z.stat().st_size,'sha256':hashlib.sha256(z.read_bytes()).hexdigest(),'verification':json.loads(run.stdout),'corruptions_rejected':checks,'package_CPU_s':time.process_time()-t0,'scope':'integrity plus documentary calculations only; no CNS'}
(p/'ENTREGA.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(rec))

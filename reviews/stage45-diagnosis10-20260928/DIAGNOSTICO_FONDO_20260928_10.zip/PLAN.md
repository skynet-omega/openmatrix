# Diagnóstico solicitado por el usuario — 28-09-2026

El usuario pide explicar qué bloquea las etapas4/5: pesos, leyes celulares, datos,
predictor/escáner, laboratorio, indexación y organización. No pide otra simulación
para esta consulta. Revisar recursos originales pertinentes y contrastar con los
tres asesores existentes. Cero subagentes nuevos y cero CNS/GPU.

## Propuesta inicial del autor, antes de recibir esta ronda de revisiones

Exposición declarada: conozco las campañas40–52 y las revisiones anteriores de los
asesores. Esta propuesta es previa a sus nuevas respuestas, no ciega al historial.

1. **Identificación funcional incompleta.** El grafo anatómico y los tipos no fijan
   todos los signos, eficacias, cinéticas, estados ni acoplamientos que necesitamos.
   No atribuir el fallo a pesos individuales sin inspeccionar su procedencia y el
   modelo efectivamente ejecutado. Discriminador: mapa ecuación/parámetro/dato de
   calibración y predicción de intervenciones no usadas al elegirlo. Falsador de
   esta prioridad: una interfaz corregida y controlada basta con leyes conservadas.
2. **Entrada, estado y cuerpo no identificados conjuntamente.** El contraste aéreo
   conserva confusión de cantidad/configuración; la excitabilidad basal no basta
   para respuesta olfativa selectiva. Hay posibles faltas de contexto/puertos, sin
   demostrar que una sea la causa. Discriminador: entrada emparejada, intervención
   de estado con no-op y contexto temporal con marginales emparejadas, por separado.
3. **Lector y herramientas describen más de lo que explican causalmente.** Un
   predictor de registros o un escáner no garantizan que sabemos qué intervención
   cambiará la conducta ni que la variable del modelo equivalga al observable real.
   Discriminador: predicciones congeladas sobre intervenciones excluidas del ajuste,
   comparadas con controles simples y medidas de conducta online.

Organización y actualización son una cuarta pregunta de ingeniería: medir enlaces,
cobertura de recursos y vigencia del punto de entrada, sin llamar “causa cerebral”
a un índice atrasado ni suponer que muchos archivos implican evidencia perdida.
Evitar ajustar conexiones una a una para fabricar navegación; primero parámetros
compartidos por tipos/receptores y observables que los distingan, sólo si el código
y datos justifican esa escala. No prometer que ese procedimiento garantice éxito.

## Presupuesto y entrega

Hasta180sCPU locales propios y120sCPU del asesor Motor,300s agregados;4GiBRAM,
30MiB de archivos nuevos,0CNS/GPU,25min de revisión activa. Consultas externas
de razonamiento/web no se contabilizan como CPU local; no contratar recursos.
Ninguna descarga masiva, instalación ni ajuste del organismo. Inspeccionar índices
y un conjunto explícito de recursos relevantes, verificando archivos originales.
Máximo dos prototipos por ronda sigue vigente; en esta consulta no hay prototipo.

Resultado: diagnóstico propio y contraste de asesores, evidencia concreta de
modelo/herramientas/datos, correcciones mínimas de continuidad si procede, y una
ruta para decidir sin calibración manual de millones de conexiones. Mantener
negativos, hashes y límites. No reabrir la arqueología completa ni trasladar repositorios.

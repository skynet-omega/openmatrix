# AXIOMA_ASTRA

Investigación de una abstracción causal de inteligencia biológica; el control de una mosca simulada es una prueba instrumental, no el objetivo completo. [Objetivo de fondo](OBJETIVO_DE_FONDO.md).

**Estado al28-09-2026: etapas4/5 abiertas.** La campaña52 corrigió una interfaz de unidades y amplió la observación, pero no demostró orientación ni recuperación. [Resultados52](campanas/etapa45_reparacion_observada_20260927_52/RESULTADOS.md).

- [Mapa vigente](MAPA_VIGENTE.md): dónde están preparación, experimentos, datos, artículos y herramientas; distingue lo actual de lo histórico.
- [Diagnóstico de fondo](investigacion/diagnostico_fondo_20260928_10/INFORME.md): qué sabemos del bloqueo, qué falta identificar y contraste con los tres asesores.
- [Estado y cronología](ESTADO_ACTUAL.md): resultados, presupuestos, comandos y pendientes.
- [Alternativas A/B/C](motor_nuevo/PLAN_ABC.md): entrada sensorial, transmisión/estado y lectura corporal; los bloques antiguos son antecedentes.

Motor C++/CUDA prepara el siguiente contraste JO con cantidad emparejada. Esta revisión no ejecutó otra simulación. Mantener el cuerpo actual y posponer la integración completa de patas.

**Laboratorio:** la entrada `laboratorio.py` consulta MATRIX histórico; no carga automáticamente la preparación de la última campaña. Consultar el mapa antes de interpretar su estado.

La versión extensa anterior de este README quedó conservada con hash en [el expediente10](investigacion/diagnostico_fondo_20260928_10/CONTINUIDAD_PREVIA.json); no se borraron resultados ni fuentes. [Mandato](AGENTS.md).

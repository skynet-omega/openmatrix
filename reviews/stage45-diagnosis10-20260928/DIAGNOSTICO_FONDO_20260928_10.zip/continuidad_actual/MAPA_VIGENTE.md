# Mapa vigente de acceso — 28-09-2026

**Etapas4/5 abiertas.** Última campaña cerrada y verificada de esta línea:52. Motor C++/CUDA prepara el contraste JO emparejado posterior; consultar su contrato/resultados cuando existan. No confundir preparación con ejecución ni un piloto neuronal con admisión conductual.

| Necesidad | Entrada y alcance |
|---|---|
| Objetivo y mandato | [OBJETIVO_DE_FONDO.md](OBJETIVO_DE_FONDO.md), [AGENTS.md](AGENTS.md). Las etapas son pruebas instrumentales del objetivo amplio. |
| Diagnóstico actual | [Diagnóstico10](investigacion/diagnostico_fondo_20260928_10/INFORME.md): modelo, datos, herramientas, organización y tres rutas. |
| Evidencia CNS reciente | [Resultados52](campanas/etapa45_reparacion_observada_20260927_52/RESULTADOS.md), [cierre](campanas/etapa45_reparacion_observada_20260927_52/CIERRE.md), [contrato](campanas/etapa45_reparacion_observada_20260927_52/PILOT_PLAN.json). |
| Preparación efectiva de52 | [Operador48/sham](campanas/etapa45_composicion_20260927_48/sham/final_state/effective_operator.json). La cabecera del constructor no describe todas las transformaciones posteriores. |
| Alternativas y continuidad | [PLAN_ABC](motor_nuevo/PLAN_ABC.md), [ESTADO_ACTUAL](ESTADO_ACTUAL.md). Los bloques fechados inferiores conservan historia; no son planes simultáneos. |
| Escáner/predictor/Dictionary Learning | [Herramientas09](investigacion/herramientas_causales_20260927_09/RESULTADOS.md), [alcances comprobados10](investigacion/diagnostico_fondo_20260928_10/INFORME.md). Observación no implica ruta causal; 52 amplió la observación temporal de DN. |
| Datos y artículos históricos | [Catálogo MATRIX](/home/daroch/AXIOMA_FLYWIRE/matrix/catalogo/README.md), [biblioteca](/home/daroch/AXIOMA_FLYWIRE/matrix/recursos_cientificos/README.md). Sólo lectura; disponibilidad y validación son cosas distintas. |
| Complemento ASTRA | [Índice23Sep](biblioteca_revision_20260923/ejecucion_02/INDICE_COMPLEMENTARIO.md). Es un corte fechado; las campañas posteriores se consultan arriba. |
| Datos pertinentes y límites | [Inventario focal10](investigacion/diagnostico_fondo_20260928_10/EVIDENCIA_LOCAL.json), [cobertura del laboratorio](investigacion/diagnostico_fondo_20260928_10/aporte_motor/INFORME_FINAL.md). Contenedor descargado, contenido extraído y calibración validada no son equivalentes. |
| Laboratorio histórico | [laboratorio.py](laboratorio.py) delega a MATRIX y su configuración histórica. No representa automáticamente48/52 ni el estado reciente de ASTRA. No se cambió ese checkpoint. |

A continuación se estudian A: entrada sensorial emparejada, B: transmisión/estado identificable, C: lector y cuerpo con feedback. Se conserva la prioridad global de orientación con cuerpo actual; CNS→VNC acotado; músculos y seis patas posteriores. No hay garantía de éxito ni necesidad de ajustar cada conexión manualmente.

Las copias anteriores de los puntos de entrada y sus hashes están en [continuidad previa](investigacion/diagnostico_fondo_20260928_10/CONTINUIDAD_PREVIA.json). El informe10 es una revisión focal, no una nueva simulación ni una indexación exhaustiva.

# Expediente de diagnóstico10

Abrir INFORME.md. Evidencia focal, asesorías, mapa y cambios documentales conservados; fuentes científicas primarias enlazadas en el informe. Este paquete pequeño NO incluye ni reproduce los datasets biológicos, el organismo completo o las simulaciones anteriores. Las rutas absolutas identifican recursos del entorno original; no sustituyen los archivos necesarios para ninguna ejecución que se afirme reproducida aquí.

Verificación corta, desde la carpeta extraída:

```bash
python3 -B -O verify_packet.py
```

Reproducción completa de las mediciones DOCUMENTALES de este expediente (no CNS):

```bash
python3 -B -O rebuild_measurements.py > MEDICIONES_RECONSTRUIDAS.md
cmp MEDICIONES.md MEDICIONES_RECONSTRUIDAS.md
```

`inspect_surface.py` sólo puede repetir la inspección original donde existan los recursos originales; no es un simulador portable. Las copias anteriores de README/ESTADO/PLAN conservan su texto literalmente y sus enlaces relativos corresponden a su ubicación original. `continuidad_actual/` conserva la nueva entrada. No se modificaron fuentes ni parámetros del organismo; por ello no hay diff algorítmico ni nuevo checkpoint. Versiones consultadas en HERRAMIENTAS_METADATA.json.

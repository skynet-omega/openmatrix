"""Read-only evidence inventory; no model execution or historical mutations."""
from pathlib import Path
import datetime,hashlib,json,re,resource,time,zipfile

H=Path(__file__).resolve().parent
ROOT=H.parents[1];OLD=ROOT.parent/'AXIOMA_FLYWIRE/matrix'
resource.setrlimit(resource.RLIMIT_CPU,(45,46))
start=time.process_time()
def stamp(p):
    if not p.is_file():return dict(path=str(p),exists=False)
    out=dict(path=str(p),exists=True,bytes=p.stat().st_size,
        mtime_utc=datetime.datetime.fromtimestamp(p.stat().st_mtime,datetime.timezone.utc).isoformat())
    if p.stat().st_size<=2*1024**2:out['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
    else:out['hash_scope']='Not rehashed; presence/size only'
    return out
def links(p):
    text=p.read_text();found=[];ignored=[]
    for raw in re.findall(r'\[[^\]]*\]\(([^)]+)\)',text):
        target=raw.strip().strip('<>')
        if re.match(r'^[a-zA-Z]+:',target) or target.startswith('#'):continue
        target=target.split('#')[0]
        if not target or not re.search(r'\.(md|json|py|npz|npy|zip|csv|html|txt|cu|pdf|mat)$',target,re.I):
            ignored.append(raw);continue
        q=Path(target)
        if not q.is_absolute():q=p.parent/q
        found.append(dict(target=raw,resolved=str(q.resolve()),exists=q.is_file()))
    return dict(source=stamp(p),lines=len(text.splitlines()),file_links=len(found),
        missing=[v for v in found if not v['exists']],unclassified_local_targets=ignored,
        scope='Syntactic local file-link sample only, not scientific validation or all-disk inventory')
def save(name,value):
    p=H/name
    if p.exists():raise ValueError('Immutable observation '+name)
    p.write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n')

catalog=json.loads((OLD/'catalogo/catalogo.json').read_text())
index_text=(ROOT/'biblioteca_revision_20260923/ejecucion_02/INDICE_COMPLEMENTARIO.md').read_text()
readmes=[ROOT/'README.md',ROOT/'ESTADO_ACTUAL.md',ROOT/'motor_nuevo/PLAN_ABC.md',
    OLD/'catalogo/README.md',OLD/'recursos_cientificos/README.md',
    ROOT/'biblioteca_revision_20260923/ejecucion_02/INDICE_COMPLEMENTARIO.md']
surface=[links(p) for p in readmes]
resources=[]
for x in catalog['availability']['records']:
    if x.get('doi') not in ('10.5061/dryad.k06kh8f','10.5061/dryad.1ns1rn8xd','10.5061/dryad.v15dv420q','10.5061/dryad.bk3j9kdd1'):continue
    spec=x['path'];outer,sep,member=spec.partition('!');p=Path(outer)
    item=dict(doi=x['doi'],study=x.get('study'),path=spec,declared_bytes=x['bytes'],outer=stamp(p),
        usage_in_old_index=x.get('usage'),transfer_limit=x.get('transfer_limit'))
    if sep and p.is_file():
        with zipfile.ZipFile(p) as z:
            m=z.getinfo(member)
            item['member']=dict(name=member,bytes=m.file_size,crc32=f'{m.CRC:08x}',size_matches=m.file_size==x['bytes'],
                scope='Central-directory metadata only; no payload extraction or fresh full hash')
    resources.append(item)
paths=[OLD/'src/anatomical_rate_brain.py',OLD/'src/hybrid_visual_brain.py',
    OLD/'work/mechanism_predictor_20260916/README.md',OLD/'work/mechanism_predictor_followup_20260916/README.md',
    OLD/'work/jaxley_adoption_20260917/README.md',OLD/'config/differentiable_toolchain_v1.json',
    ROOT/'laboratorio.py',OLD/'laboratorio.py',OLD/'config/project_state.json',
    ROOT/'investigacion/dnb05_20260923/README.md',ROOT/'investigacion/dnb05_20260923/2PAnalysisCode.zip',
    ROOT/'investigacion/herramientas_causales_20260927_09/fuentes/Kathman2026_readme.rtf',
    ROOT/'campanas/etapa45_reparacion_observada_20260927_52/PILOT_PLAN.json',
    ROOT/'campanas/etapa45_reparacion_observada_20260927_52/RESULTADOS.md',
    ROOT/'campanas/etapa45_reparacion_observada_20260927_52/coefficient51.cu',
    ROOT/'motor_nuevo/animation_v7_12s_20260926/SCANNER_RECEIPT.json']
scanner=json.loads(paths[-1].read_text())
scanner_selected={k:scanner[k] for k in ['source_run','neuron_count','source_neuron_count','displayed_connections','edge_selection','edge_meaning']}
scanner_selected['samples']=len(scanner['sample_ms']);scanner_selected['first_last_ms']=[scanner['sample_ms'][0],scanner['sample_ms'][-1]]
legacy=json.loads((OLD/'config/project_state.json').read_text())
old_status=json.loads((OLD/'config/organism_status.json').read_text())
result=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    no_CNS=True,no_GPU=True,read_only_historical=True,entrypoints=surface,resources=resources,
    inspected_sources=[stamp(p) for p in paths],scanner=scanner_selected,
    catalog=dict(statistics=catalog['statistics'],availability_checked=catalog['availability']['checked_utc'],
        new_52_in_complementary_index='etapa45_reparacion_observada_20260927_52' in index_text,
        historical_source_note='September23 complementary snapshot is immutable, not claimed current'),
    laboratory=dict(astra_wrapper_target=str(OLD/'laboratorio.py'),
        historical_active_checkpoint=old_status.get('active_checkpoint'),historical_next_milestone=legacy.get('next_milestone'),
        current_52_source_checkpoint=json.loads((ROOT/'campanas/etapa45_reparacion_observada_20260927_52/PILOT_PLAN.json').read_text())['source_checkpoint'],
        scope='Static dispatch/config inspection; laboratory state command and runtime not executed'),
    CPU_s=time.process_time()-start,scope='Focal diagnosis of explicit resources; no exhaustive physiology/data/version audit')
save('EVIDENCIA_LOCAL.json',result)
print(json.dumps(dict(CPU_s=result['CPU_s'],resources=len(resources),sources=len(paths),
    file_link_counts={Path(x['source']['path']).as_posix():dict(links=x['file_links'],missing=len(x['missing'])) for x in surface},
    scanner=scanner_selected),ensure_ascii=False))

if __name__=='__main__':pass

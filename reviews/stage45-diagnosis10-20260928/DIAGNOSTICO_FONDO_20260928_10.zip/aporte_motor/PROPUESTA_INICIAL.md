# Formulación propia previa al contraste de esta ronda

Exposición declarada: conozco y participé en las revisiones47–52 y herramientas09, incluido el negativoG/I, la coberturaDN y la fronteraFP32. Leí primero los tres índices solicitados. No he leído la propuesta nueva de Matrix ni las nuevas respuestas de otros asesores. La separación temporal de propuestas no convierte nuestra evidencia compartida en replicaciones independientes.

**Mi hipótesis de trabajo no es que falten166.700 ajustes manuales. Falta localizar qué parte de la transformación estímulo→estado→acción falla y qué parámetros de esa parte son identificables con datos comparables.** El motor puede integrar fielmente un modelo insuficiente. Un modelo que se mueve tampoco queda biológicamente validado.

## Tres rutas distintas a contrastar

1. **Interfaz y contexto del experimento.** La entrada virtual puede no representar un estímulo que provoque la conducta pretendida, o mezclar dirección con cantidad. Favorecen esta ruta la desigualdadJO y el fallo físico corregido; la limitan el que sí hay respuesta neuronal y que el fallo de unidades no rescató orientación. Discriminador: intervención sensorial acotada con cantidad comprobada en la frontera efectiva, observación de propagación y control relevante. Falsador de la explicación basada sólo en cantidad: el efecto diferencial persiste al emparejarla; todavía no prueba una ley direccional útil. No añadir hambre o visión como rescate sin correspondencia experimental.

2. **Ley dinámica y parametrización efectiva.** El conectoma restringe quién conecta con quién y magnitudes anatómicas, pero no determina por sí solo todos los signos, receptores, ganancias, tiempos y estado. Favorece esta ruta el bloqueo de ciertos lectores bajo una ley y su activación basal bajoG/I; la limita queG/I no gana selectividad olfativa. Discriminador: identificar un conjunto pequeño y compartido de parámetros por tipo celular/circuito a partir de observables compatibles y probar intervenciones no utilizadas en el ajuste. Falsador de una familia: no reproduce signo, magnitud y tiempo en esas intervenciones sin cambiar parámetros. Conservar varias soluciones si los datos no las distinguen; no declarar una ley verdadera por ajustar una traza.

3. **Lectura neural, efector y lazo corporal.** Actividad amplia puede existir sin que el lector elegido represente bien el movimiento; además52 deja el giro sin aplicar. Favorecen esta ruta lasDN fuera del panel anterior y la separación entre mando y conducta; la limitan el no haber demostrado un comando correcto oculto y los negativos previos de lectores alternativos. Discriminador: lector fijado por evidencia externa/causal y prueba física online frente a control/replay, sin escoger neuronas por la trayectoria que salga mejor. Falsador: el lector y efector no generan la respuesta corporal prevista o el feedback no mejora el control reservado. No exigir resolver todas las patas para investigar esta frontera.

## Papel de organización y herramientas

El catálogo y el escáner pueden reducir decisiones repetidas o cobertura insuficiente, pero no aportan automáticamente ecuaciones ni causalidad. Revisaré si las carencias son disponibilidad, mapeo de observables, validación o navegación documental. Un índice antiguo declarado como tal no es un dato biológico falso ni prueba que el proyecto sea irrecuperable.

Recomendación inicial: congelar el motor operativo y usar una identificación acotada de la cadena sensorial/motora; controles que decidan entre las tres rutas. No ajustar célula a célula, no construir un predictor universal como requisito y no prometerPASS. Esta propuesta se someterá ahora a inspección de fuentes concretas y1–3 referencias primarias.

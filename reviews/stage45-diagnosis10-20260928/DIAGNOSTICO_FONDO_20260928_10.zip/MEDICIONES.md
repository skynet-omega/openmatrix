# Mediciones derivadas de los recibos

Se regeneran desde los JSON conservados, sin abrir el CNS ni los datasets. No son una nueva medición biológica ni reproducen todo el inventario.

| Medición | Valor |
|---|---:|
| Células mostradas por el escáner12s | 20342 |
| Células de su preparación | 166700 |
| Enlaces anatómicos mostrados | 887 |
| Muestras del escáner | 121 |
| Arrays efectivos con hash comprobado | 6 |
| SQLite inspeccionados | 5 |
| SQLite con registros | 4 |
| Máximo de registros por SQLite; no suma de copias | 334 |
| Máximo de observaciones por SQLite | 34872 |
| Versiones contrastadas | 9 |
| Enlaces faltantes antes de corregir: README.md | 0 |
| Enlaces faltantes antes de corregir: ESTADO_ACTUAL.md | 0 |
| Enlaces faltantes antes de corregir: motor_nuevo/PLAN_ABC.md | 3 |

CPU cronometrada de comprobaciones específicas: superficie 0.122401 s; arrays Motor 0.086762 s; SQLite Motor 0.017418 s; metadatos 0.011407 s. No es el coste total de toda lectura/redacción.

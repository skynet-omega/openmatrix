from pathlib import Path
import hashlib,json,subprocess,sys
p=Path(__file__).resolve().parent
m=json.loads((p/'MANIFEST.json').read_text())
for row in m['files']:
 f=p/row['path']
 if not f.is_file() or f.stat().st_size!=row['bytes'] or hashlib.sha256(f.read_bytes()).hexdigest()!=row['sha256']:raise RuntimeError('integridad: '+row['path'])
r=subprocess.run([sys.executable,'-B','-O',str(p/'rebuild_measurements.py')],check=True,capture_output=True)
if r.stdout!=(p/'MEDICIONES.md').read_bytes():raise RuntimeError('mediciones derivadas distintas')
print(json.dumps({'files_verified':len(m['files']),'measurements_rebuilt':True,'scope':'Documentary receipt integrity; no original CNS or biological dataset reproduced','CNS_ms':0}))
